(function ($) {
$.fn._vs.mouse = {
	    init:function(){},
	}
})
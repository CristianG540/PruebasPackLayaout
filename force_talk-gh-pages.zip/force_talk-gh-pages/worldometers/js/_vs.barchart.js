(function ($) {
  
  $.extend($.fn.visualSedimentation.vs,test = function(){
	 console.log("ici visualSedimentation.fn.test")
  });

})(jQuery);

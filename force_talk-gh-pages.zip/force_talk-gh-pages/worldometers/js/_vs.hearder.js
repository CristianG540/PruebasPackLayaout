/*!
 * Visual Sedimentation Library v0.01
 * http://www.visualsedimentation.org/
 *
 * Copyright 2013, Samuel Huron & Romain Vuillemont
 * Licensed under the CeCILL-B or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 *
 *
 *
 *
 * Includes jquery.js
 * http://jquery.com/
 * Copyright 2010, John Resig
 * Released under Dual licensed under the MIT or GPL Version 2 licenses.
 * 
 * Includes d3.js
 * http://d3js.org/
 * Copyright 2012, Michael Bostock
 * Released under BSD licenses.
 * 
 * Includes Box2DWeb
 * http://www.gphysics.com
 * Copyright 2006, Erin Catto 
 * Released under zlib License.
 * 
 * Includes Sizzle.js
 * http://sizzlejs.com/
 * Copyright 2010, The Dojo Foundation
 * Released under the MIT, BSD, and GPL Licenses.
 *
 * Date: Tue Jan 01 14:25:48 2010 -0500
 */